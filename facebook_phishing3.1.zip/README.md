![alt text]()
<h1>Facebook Phishing 3.1 - Fake facebook Page for Social Engineering</h1>                                                 
<p>
Página falsa do Facebook 2022 totalmente idependente (não busca arquivos na internet) desenvolvida e programada para salvar informações de logins e senhas das vitimas.
</p>
<p1>
 
<h3 style="text-align: left;">
<span style="font-family: arial;">Dúvidas && Recursos</span>
</h3>

<div>
<ul style="text-align: left;">
<li><span style="font-family: arial;">Email e senha não salva: chmod -R 777 login.php</span></li>
<li><span style="font-family: arial;">Não redirecionou para página certa: Modifique o link meta em login.php </span></li>
<li><span style="font-family: arial;">Não encontrei a senha: Abra local.txt</span></li>

 <p>Autor :-https://instagram.com/brazilian_mafia_ofc</p>
 
<h3 style="text-align: left;">
<span style="font-family: arial;">Instalaçao & Uso
</h3>

```bash 
Mova os arquivos para /var/www/html/
Digite no terminal: service apache2 start
Digite no navegador: 127.0.0.1

```
 
Nota: Teste para verificar se tudo está funcionando antes de usá-lo.

<p>
Testado no apache do kali linux.
</p>

<h4>
Nota: Mensagem de que a página contém malware pode ser exibido para a vitima.
</h4>

>As senhas capituradas estaram salvas no arquivo .txt


Esta informação é apenas para fins educacionais e não somos responsáveis por qualquer tipo de atividade ilegal feita por esta ferramenta.

>Divirta-se!!!

